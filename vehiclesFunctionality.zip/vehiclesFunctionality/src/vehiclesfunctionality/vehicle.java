
package vehiclesfunctionality;

public interface vehicle {
    public void startEngine();
    public    void stopEngine();
    public  void shiftGears(int gear);
    public  void accelerate(int i);
    public  void applyBrakes();
    public  void turnLights(String b);
    public  void indicators(String d);
        
}
