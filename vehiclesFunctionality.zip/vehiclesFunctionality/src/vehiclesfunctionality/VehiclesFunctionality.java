
package vehiclesfunctionality;
import java.io.*;
import java.util.Scanner;

public class VehiclesFunctionality {

    public static void main(String[] args) {
        
        
      car c=new car();
      c.startEngine();
      Scanner sc=new Scanner(System.in);
        System.out.println("Enter gears number to shift: ");
        int a=sc.nextInt();
        c.shiftGears(a);
        System.out.println("Enter acceleration Value: ");
        int ac=sc.nextInt();
        c.accelerate(ac);
        System.out.println("Do you want to breaks :");
        String br=sc.next();
        if (br.equalsIgnoreCase("yes"))
        {
        c.applyBrakes();
        }
        else 
        {
            System.out.println("Keep driving");
        }
        System.out.println("Do you want to turn the lights on? :");
        String lt=sc.next();
        if(lt.equalsIgnoreCase("yes"))
        {
            c.turnLights(br);
        }
        System.out.println("Input indicators position: ");
        String in=sc.next();
        c.indicators(in);
        System.out.println("Do you want to stop the car engine? :");
        String st=sc.next();
        if (st.equalsIgnoreCase("yes"))
        {
            c.stopEngine();
        }
    
         bus b=new bus();
      b.startEngine();
      
        System.out.println("Enter gears number to shift: ");
        int as=sc.nextInt();
        b.shiftGears(as);
        System.out.println("Enter acceleration Value: ");
        int dc=sc.nextInt();
        b.accelerate(dc);
        System.out.println("Do you want to breaks :");
        String brk=sc.next();
        if (brk.equalsIgnoreCase("yes"))
        {
        b.applyBrakes();
        }
        else 
        {
            System.out.println("Keep driving");
        }
        System.out.println("Do you want to turn the lights on? :");
        String ltb=sc.next();
        if(ltb.equalsIgnoreCase("yes"))
        {
            b.turnLights(br);
        }
        System.out.println("Input indicators position: ");
        String ind=sc.next();
        b.indicators(ind);
        System.out.println("Do you want to stop the car engine? :");
        String sts=sc.next();
        if (sts.equalsIgnoreCase("yes"))
        {
            b.stopEngine();
        }
        
        
         truck t=new truck();
      t.startEngine();
      
        System.out.println("Enter gears number to shift: ");
        int az=sc.nextInt();
        t.shiftGears(az);
        System.out.println("Enter acceleration Value: ");
        int acc=sc.nextInt();
        t.accelerate(acc);
        System.out.println("Do you want to breaks :");
        String brv=sc.next();
        if (brv.equalsIgnoreCase("yes"))
        {
        t.applyBrakes();
        }
        else 
        {
            System.out.println("Keep driving");
        }
        System.out.println("Do you want to turn the lights on? :");
        String ltc=sc.next();
        if(ltc.equalsIgnoreCase("yes"))
        {
            t.turnLights(br);
        }
        System.out.println("Input indicators position: ");
        String inq=sc.next();
        t.indicators(inq);
        System.out.println("Do you want to stop the car engine? :");
        String stf=sc.next();
        if (stf.equalsIgnoreCase("yes"))
        {
            t.stopEngine();
        }
        
    }
    
}
