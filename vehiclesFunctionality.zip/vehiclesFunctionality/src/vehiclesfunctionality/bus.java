/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehiclesfunctionality;

/**
 *
 * @author Avil's
 */
public class bus implements vehicle {
     int gears;
    int acceleration=0;

    @Override
    public void startEngine() {
        System.out.println("Bus is started");
    }

    @Override
    public void stopEngine() {
        System.out.println("Bus is stopped.");
        
    }

    @Override
    public void shiftGears(int gear) {
        System.out.println("Gear change from "+gears);
       gears=gear;
       System.out.println("Gear change to "+gears);
        
    }

    @Override
    public void accelerate(int i) {
        if (i>acceleration)
        {
            System.out.println("Acceleration increased into "+i);
            System.out.println("Acceleration increased from "+acceleration);
            acceleration +=i;
        }
        else 
        {
             System.out.println("Acceleration decreased into "+i);
            System.out.println("Acceleration decreased from "+acceleration);
            acceleration -=i;
        }
        
    }

    @Override
    public void applyBrakes() {
        System.out.println("Speed set to 0");
        acceleration=0;
        
    }

    @Override
    public void turnLights(String b) {
        if (b.equalsIgnoreCase("yes"))
        {
            System.out.println("Light's on");
        }
        else 
        {
            System.out.println("Light's off");
        }
    }

    @Override
    public void indicators(String g) {
        if (g.equalsIgnoreCase("left"))
        {
            System.out.println("Left  Indicators on");
        }
        else if (g.equalsIgnoreCase("right"))
        {
            System.out.println("Right  Indicators on");
        }
        else 
        {
            System.out.println("Indicators off");
        }
    
}
}
